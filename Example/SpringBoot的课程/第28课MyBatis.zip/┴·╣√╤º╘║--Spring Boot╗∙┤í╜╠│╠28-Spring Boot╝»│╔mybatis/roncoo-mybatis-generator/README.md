龙果开源-Mybatis代码自动生成工具


###项目介绍
1. 基于mybatis-generator，增加了多个插件。


###帮助文档
1. 修改src/test/resources/下的配置文件
2. 运行src/test/test/下的main方法即可

###技术交流
技术交流群：546588570

