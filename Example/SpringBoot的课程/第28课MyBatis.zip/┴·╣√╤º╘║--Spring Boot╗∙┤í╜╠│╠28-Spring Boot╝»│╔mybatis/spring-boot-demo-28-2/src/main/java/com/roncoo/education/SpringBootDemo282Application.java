package com.roncoo.education;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemo282Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemo282Application.class, args);
	}
}
