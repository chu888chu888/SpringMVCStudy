package com.gaussic.model;

import java.util.List;

/**
 * Created by dzkan on 2016/5/24.
 */
public class UserListForm {

    private List<UserEntity> users;

    public List<UserEntity> getUsers() {
        return users;
    }

    public void setUsers(List<UserEntity> users) {
        this.users = users;
    }
}
